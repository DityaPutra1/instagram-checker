export function parseInstagram(files) {
  let followers = [];
  let following = [];

  for (const file of files) {
    const name = file.name.toLowerCase();
    const text = file.text ? null : null;
  }

  return Promise.all(
    [...files].map(async (file) => {
      return {
        name: file.name.toLowerCase(),
        json: JSON.parse(await file.text()),
      };
    })
  ).then((allFiles) => {
    allFiles.forEach(({ name, json }) => {
      // FOLLOWERS
      if (name.includes("followers")) {
        followers = json.map((item) => item.string_list_data?.[0]?.value);
      }

      // FOLLOWING
      if (name.includes("following")) {
        following = json.relationships_following.map(
          (item) => item.title
        );
      }
    });

    followers = followers.filter(Boolean);
    following = following.filter(Boolean);

    const notFollowBack = following.filter(
      (user) => !followers.includes(user)
    );

    const fans = followers.filter(
      (user) => !following.includes(user)
    );

    return {
      followers,
      following,
      notFollowBack,
      fans,
    };
  });
}
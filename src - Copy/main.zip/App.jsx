import { useState } from "react";
import "./App.css";

import { parseInstagram } from "./utils/parser";

import Navbar from "./components/Navbar";
import StatsCard from "./components/StatsCard";
import Search from "./components/Search";
import ResultList from "./components/ResultList";
import Footer from "./components/Footer";

export default function App() {
  const [data, setData] = useState(null);
  const [keyword, setKeyword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleUpload(e) {
    try {
      setLoading(true);
      setError("");

      const result = await parseInstagram(e.target.files);

      setData(result);
    } catch (err) {
      console.error(err);
      setError("File Instagram tidak dapat dibaca.");
    } finally {
      setLoading(false);
    }
  }

  const filteredUsers =
    data?.notFollowBack.filter((user) =>
      user.toLowerCase().includes(keyword.toLowerCase())
    ) || [];

  return (
    <div className="container">
      <Navbar />

      <div className="upload">
        <input
          type="file"
          multiple
          accept=".json"
          onChange={handleUpload}
        />
      </div>

      {loading && <h3>Membaca file Instagram...</h3>}

      {error && <p className="error">{error}</p>}

      <div className="cards">
        <StatsCard
          title="Followers"
          value={data?.followers.length || 0}
          color="#38bdf8"
        />

        <StatsCard
          title="Following"
          value={data?.following.length || 0}
          color="#22c55e"
        />

        <StatsCard
          title="Tidak Follow Back"
          value={data?.notFollowBack.length || 0}
          color="#ef4444"
        />

        <StatsCard
          title="Fans"
          value={data?.fans.length || 0}
          color="#f59e0b"
        />
      </div>

      <Search
        keyword={keyword}
        setKeyword={setKeyword}
      />

      <ResultList users={filteredUsers} />

      <Footer />
    </div>
  );
}
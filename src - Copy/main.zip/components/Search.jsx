export default function Search({ keyword, setKeyword }) {
  return (
    <input
      className="search"
      placeholder="🔍 Cari username..."
      value={keyword}
      onChange={(e) => setKeyword(e.target.value)}
    />
  );
}